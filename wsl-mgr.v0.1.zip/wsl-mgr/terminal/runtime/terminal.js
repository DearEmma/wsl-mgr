'use strict';
const term = new Terminal({fontFamily:'Consolas, "Microsoft YaHei", monospace',fontSize:14,scrollback:5000,cursorBlink:true,allowProposedApi:false,theme:{background:'#181818',foreground:'#eeeeee'}});
const fit = new FitAddon.FitAddon();
term.loadAddon(fit);term.open(document.getElementById('terminal'));
const send = value => window.chrome.webview.postMessage(value);
term.onData(data=>send('input:'+data));
term.onResize(size=>send('size:'+size.cols+','+size.rows));
term.onSelectionChange(()=>send('selection:'+(term.hasSelection()?'1':'0')));
const copySelection = ()=>{const text=term.getSelection();if(text)send('copy:'+text);};
document.getElementById('terminal').addEventListener('contextmenu',e=>{
 e.preventDefault();send('context:'+(term.hasSelection()?'1':'0'));
});
term.attachCustomKeyEventHandler(e=>{
 if(e.ctrlKey&&e.shiftKey&&e.type==='keydown'){
  if(['KeyC','KeyV','KeyR'].includes(e.code)){
   e.preventDefault();e.stopPropagation();
   if(e.code==='KeyC')copySelection();
   else if(e.code==='KeyV')send('paste');
   else send('restart');
   return false;
  }
 }
 return true;
});
const bytes=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
window.chrome.webview.addEventListener('message',e=>{
 const s=e.data;
 if(s==='reset'){term.reset();return;}
 if(s==='copy-selection'){copySelection();term.focus();return;}
 if(s.startsWith('data:'))term.write(bytes(s.slice(5)),()=>send('ack'));
 else if(s.startsWith('note:'))term.writeln('\r\n'+s.slice(5).replace(/[\x00-\x1f\x7f]/g,' '));
 else if(s.startsWith('paste:')){term.focus();term.paste(new TextDecoder().decode(bytes(s.slice(6))));}
});
new ResizeObserver(()=>{try{fit.fit();}catch{}}).observe(document.getElementById('terminal'));
fit.fit();send('ready');term.focus();
